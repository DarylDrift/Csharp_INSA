﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Distributeur
    {
        private static string path_fprod = @"U:\5 GP\Prog Or Obj\BonusPartiel\CoursPOO-master\ListeProduit.txt";
        private static string path_fpiece = @"U:\5 GP\Prog Or Obj\BonusPartiel\CoursPOO-master\ListePieces.txt";

        public static void Init()
        {
            Init_Produit();
            Init_Stock_Piece();
        }

        public static List<Produit> Init_Produit()
        {
            List<Produit> Liste_Prod = new List<Produit>();
            //Dictionary<string,Produit> Liste_Prod = new Dictionary<string, Produit>();

            try
            {
                if (File.Exists(path_fprod))
                {
                    using (StreamReader sr = new StreamReader(path_fprod))
                    {
                        string line;
                        string[] line_;
                        string Position;
                        string Nom;
                        int Quantite;
                        int Prix;
                        int numline = 0;

                        Console.WriteLine("Liste des produits : ");
                        while ((line = sr.ReadLine()) != null)
                        {
                            
                            Console.WriteLine(line);
                            //La premiere ligne ne contient pas de produit
                            if (numline > 0)
                            {
                                line_ = line.Split('\t');
                                if (line_.Count() != 4)
                                {
                                    Console.WriteLine("Ligne " + numline + " ; Lecture du fichier d'initialisation des produits : Erreur syntaxe. Separer 4 valeurs par des tabulations");
                                }
                                else
                                {
                                    Position = line_[0];
                                    Nom = line_[1];
                                    Quantite = -1;
                                    Prix = -1;

                                    //Conversion de la donnee contenant la quantite en int
                                    try
                                    {
                                        Quantite = Convert.ToInt32(line_[2]);
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine("Lecture du fichier d'initialisation des produits : Echec de conversion de Quantite en int");
                                        Console.WriteLine("The process failed: {0}", e.ToString());
                                    }

                                    //Conversion de la donnee contenant le prix en float
                                    try
                                    {
                                        Prix = Convert.ToInt32(line_[3]);
                                    }
                                    catch (Exception e)
                                    {
                                        try
                                        {
                                            Prix = Convert.ToInt32(line_[3].Replace(".", ","));
                                        }
                                        catch (Exception e2)
                                        {
                                            Console.WriteLine("Lecture du fichier d'initialisation des produits : Echec de conversion de Prix en int");
                                            Console.WriteLine("The process failed: {0}", e2.ToString());
                                            Console.WriteLine("The process failed: {0}", e.ToString());
                                        }
                                    }

                                    //Ajout d'un element a la liste contenant les produits
                                    Liste_Prod.Add(new Produit(Position, Nom, Prix, Quantite));
                                }   
                            }
                            numline += 1;
                        }     
                    }
                }
                else
                {
                    Console.WriteLine("Le fichier relatif a " + path_fprod + "n'existe pas");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            }
            return Liste_Prod;
        }

        public static List<Piece> Init_Stock_Piece()
        {
            List<Piece> Liste_Piece = new List<Piece>();

            foreach (int Valeur in Piece.Valeurs_possibles)
            {
                Liste_Piece.Add(new Piece(Valeur, 0));
            }

            //Dictionary<string,Produit> Liste_Prod = new Dictionary<string, Produit>();
            try
            {
                if (File.Exists(path_fpiece))
                {
                    using (StreamReader sr = new StreamReader(path_fpiece))
                    {
                        string line;
                        string[] line_;
                        int Quantite;
                        int Valeur;
                        int numline = 0;

                        while ((line = sr.ReadLine()) != null)
                        {
                            //Console.WriteLine(line);
                            //La premiere ligne ne contient pas de piece
                            if (numline > 0)
                            {
                                line_ = line.Split('\t');
                                if (line_.Count() != 2)
                                {
                                    Console.WriteLine("Ligne " + numline + " ; Lecture du fichier d'initialisation des pieces : Erreur syntaxe. Separer 2 valeurs par des tabulations");
                                }
                                else
                                {
                                    
                                    Quantite = -1;
                                    Valeur = -1;

                                    //Conversion de la donnee contenant le valeur en float
                                    try
                                    {
                                        Valeur = Convert.ToInt32(line_[0]);
                                    }
                                    catch (Exception e)
                                    {
                                        try
                                        {
                                            Valeur = Convert.ToInt32(line_[0].Replace(".", ","));
                                        }
                                        catch (Exception e2)
                                        {
                                            Console.WriteLine("Ligne " + numline + " ; Lecture du fichier d'initialisation des pieces : Echec de conversion de valeur en int");
                                            Console.WriteLine("The process failed: {0}", e2.ToString());
                                            Console.WriteLine("The process failed: {0}", e.ToString());
                                        }
                                    }

                                    //Conversion de la donnee contenant la quantite en int
                                    try
                                    {
                                        Quantite = Convert.ToInt32(line_[1]);
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine("Ligne " + numline + " ; Lecture du fichier d'initialisation des pieces : Echec de conversion de Quantite en int");
                                        Console.WriteLine("The process failed: {0}", e.ToString());
                                    }

                                    //Ajout d'un element a la liste contenant les pieces
                                    if ((Piece.Valeurs_possibles.Contains(Valeur) ))
                                    {
                                        int i = 0;
                                        bool trouve = false; 
                                        while ((!(trouve)) & (i < Liste_Piece.Count()))
                                        {
                                            if ((Valeur == Liste_Piece[i].Valeur))
                                            {
                                                Liste_Piece[i].Ajout_Piece(Quantite);
                                                trouve = true; 
                                            }
                                            i += 1;
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("La Piece de " + Valeur.ToString() + " n'existe pas");
                                    }
                                }
                            }
                            numline += 1;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Le fichier relatif a " + path_fprod + "n'existe pas");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            }
            return Liste_Piece;
        }

        public static int Index_produit(List<Produit> Liste, string Demande)
        {
            int i = -1;
            if ((Liste.Count() > 0))
            {
                i = 0;
                int T_Liste = Liste.Count();
                bool trouve = false;
                while ((!(trouve)) & (i < T_Liste))
                {
                    if ((Demande == Liste[i].Position) || (Demande == Liste[i].Nom))
                    {
                        trouve = true;
                    }
                    i += 1;
                }
                if (!(trouve))
                    i = -1;
            }
            return i-1;
        }

        int Index_piece(List<Piece> Liste, int valeur)
        {
            int i = -1;
            if ((Liste.Count() > 0))
            {
                i = 0;
                int T_Liste = Liste.Count();
                bool trouve = false;
                while ((!(trouve)) & (i < T_Liste))
                {
                    if ((valeur == Liste[i].Valeur))
                    {
                        trouve = true;
                    }
                    i += 1;
                }
                if (!(trouve))
                    i = -1;
            }
            return i-1;
        }

        public static bool Produit_Disponible(List<Produit> Liste, string Demande)
        {
            int i = Index_produit(Liste, Demande);
            //Console.WriteLine(i.ToString());
            bool Disp = false;
            if ((i > -1))
            {
                if ((Liste[i].Quantite > 0))
                {
                    //Console.WriteLine(Liste[i].Quantite.ToString());
                    Disp = true;
                }
            }
            //Console.WriteLine(Disp.ToString());
            return Disp;
        }

        public static int Paiement(Produit Prod_a_payer)
        {
            int Montant_ajoute = 0;
            int piece_ajoutee = 0;
            Console.WriteLine("Le produit selectionne est " + Prod_a_payer.Nom + " au prix de " + Prod_a_payer.Prix.ToString() + " ct.");
            while ((Montant_ajoute < Prod_a_payer.Prix))
            {
                Console.Write("Ajoutez une piece : ");
                string piece = Console.ReadLine();
                try
                {
                    piece_ajoutee = Convert.ToInt32(piece);
                }
                catch (Exception e)
                {
                    try
                    {
                        piece_ajoutee = Convert.ToInt32(piece.Replace(".", ","));
                    }
                    catch (Exception e2)
                    {
                        Console.WriteLine("Echec de conversion de valeur en int");
                        Console.WriteLine("The process failed: {0}", e2.ToString());
                        Console.WriteLine("The process failed: {0}", e.ToString());
                    }
                }
                if ((Piece.Valeurs_possibles.Contains(piece_ajoutee)))
                {
                    Montant_ajoute += piece_ajoutee;
                }
                else
                {
                    Console.WriteLine("La piece ajoutee n'existe pas.");
                }
            }
            Prod_a_payer.Retrait_Article(Prod_a_payer);

            return Montant_ajoute - Prod_a_payer.Prix;
        }

        public static void Choix_et_paiement(List<Produit> liste_prod)
        {
            Console.WriteLine("Choississez le produit parmis la liste ci dessus");
            string Choix = Console.ReadLine(); 
            if (!(Produit_Disponible(liste_prod, Choix)))
            {
                while ((Produit_Disponible(liste_prod, Choix)))
                {
                    Console.WriteLine("Le produit n'existe pas");
                    Choix = Console.ReadLine();
                }
            }
                
            int rendue = Paiement(liste_prod[Index_produit(liste_prod, Choix)]);
            Console.WriteLine("Voici votre argent : " + rendue.ToString());
        }
            
        
        
    }
}
