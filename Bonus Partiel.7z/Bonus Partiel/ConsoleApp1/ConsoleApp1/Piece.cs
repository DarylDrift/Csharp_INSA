﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Piece
    {
        public static int[] Valeurs_possibles = { 1, 2, 5, 10, 20, 50, 100, 200 };

        public int Valeur { get; private set; }
        public int Quantite { get; private set; }

        public Piece(int Valeur, int Quantite)
        {
            this.Valeur = Valeur;
            this.Quantite = Quantite;
        }

        public void Retrait_Piece(int n)
        {
            this.Quantite -= n;
        }
        public void Ajout_Piece(int n)
        {
            this.Quantite += n;
        }
    }
}
