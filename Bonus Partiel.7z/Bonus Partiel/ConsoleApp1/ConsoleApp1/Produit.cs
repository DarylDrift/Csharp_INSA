﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Produit
    {
        public string Position { get; private set; }
        public string Nom { get; private set; }
        public int Prix { get; private set; }
        public int Quantite { get; private set; }

        public Produit(string Position, string Nom, int Prix, int Quantite)
        {
            this.Position = Position;
            this.Nom = Nom;
            this.Prix = Prix;
            this.Quantite = Quantite;
        }

        public void Retrait_Article(Produit Prod)
        {
            Prod.Quantite -= 1;
        }
    }
}
