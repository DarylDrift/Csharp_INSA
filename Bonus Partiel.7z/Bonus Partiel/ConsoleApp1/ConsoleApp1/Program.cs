﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Produit> a = Distributeur.Init_Produit();
            List<Piece> b = Distributeur.Init_Stock_Piece();
            Distributeur.Choix_et_paiement(a);
            Console.ReadLine();
        }
    }
}
